﻿using Android.App;
using Android.Widget;
using Android.OS;
using System.IO;
using SQLite;

namespace BookInventory
{
    [Activity(Label = "Book Inventory", MainLauncher = true)]
    public class MainActivity : Activity
    {
        // declare your controls here so they can be used across multiple methods/events 
        EditText txtISBN;
        EditText txtTitle;
        Button btnAddBook;
        ListView tblBooks;

        string filePath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.MyDocuments), "BookList.db3");
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            // initialize your declared UI controls here
            txtISBN = FindViewById<EditText>(Resource.Id.txtISBN);
            txtTitle = FindViewById<EditText>(Resource.Id.txtTitle);
            tblBooks = FindViewById<ListView>(Resource.Id.tblBooks);


            // get our button from the layout resource and attach an event to it
            btnAddBook = FindViewById<Button>(Resource.Id.btnAddBook);

            btnAddBook.Click += BtnAddBook_Click;

            try
            { // Create our connection, if the database and/or table doesn't exist create it
                var db = new SQLiteConnection(filePath);
                db.CreateTable<Book>();
            }
            catch (IOException ex)
            {

            var reason = string.Format("Failed to create Table - reason {0}", ex.Message); 
            Toast.MakeText(this, reason, ToastLength.Long).Show();

            }

            void BtnAddBook_Click(object sender, System.EventArgs e)
            {
                string alertTitle, alertMessage;
                if (!string.IsNullOrEmpty(txtTitle.Text))
                {
                    var newBook = new Book { BookTitle = txtTitle.Text, ISBN = txtISBN.Text };

                    var db = new SQLiteConnection(filePath);
                    db.Insert(newBook);
                    alertTitle = "Success";
                    alertMessage = "Book added successfully!";
                }
                else
                {
                    alertTitle = "Failed to add book";
                    alertMessage = "Enter a valid book title";
                }

                AlertDialog.Builder alert = new AlertDialog.Builder(this);
                alert.SetTitle(alertTitle);
                alert.SetMessage(alertMessage);
                alert.SetPositiveButton("OK", (senderAlert, args) =>
                {
                    Toast.MakeText(this, "Continue!", ToastLength.Short).Show();

                });
                Dialog dialog = alert.Create();
                dialog.Show();
            }
        }
    }
}

